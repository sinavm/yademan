# Yademan | یادمان

A bilingual Persian-English memorial archive for victims of Dey 1404.

## Public release status

This repository is intended for public publication. The website is a static, bilingual foundation. The public dataset is deliberately empty until each record has been checked against reliable sources and approved for publication. The source extraction contains 3,301 rows, not 3,301 verified identities.

## Stack

- Semantic HTML
- Responsive CSS with reduced-motion support
- Vanilla JavaScript for the language switch
- Python 3 for reproducible data audits
- GitHub Actions for GitHub Pages deployment

No build-time package manager or external runtime dependency is required.

## Local preview

Run `python3 -m http.server 8000` from the repository root and open `http://localhost:8000`.

## Data governance

- `data/approved.json` is the only public record source. It is currently empty.
- Raw extraction files, working notes, candidate images and private review material must never be committed.
- Every published claim needs a traceable source and review date.
- A name-search result is not proof that an image depicts a person.
- Portraits require identity verification, a documented source, and a clear license or permission basis.
- Do not publish private contact details, identity numbers, or precise private addresses.
- Provide a correction and removal process for every public record.

See `docs/content-policy.md` and `docs/data-audit.txt`.

## GitHub Pages

The workflow in `.github/workflows/deploy.yml` deploys the repository root when changes are pushed to `main`. In repository settings, enable Pages with GitHub Actions as the source.
