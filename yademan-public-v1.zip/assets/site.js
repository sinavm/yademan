const button=document.querySelector("#language")
const root=document.documentElement
let language="fa"
button.addEventListener("click",()=>{
language=language==="fa"?"en":"fa"
root.lang=language
root.dir=language==="fa"?"rtl":"ltr"
button.textContent=language==="fa"?"EN":"FA"
document.querySelectorAll("[data-fa]").forEach(node=>{
node.textContent=node.dataset[language]
})
})
