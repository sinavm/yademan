# Content policy

A source row is a lead for research and is not proof by itself.

A public record must have a stable identifier and at least one traceable source. Important facts should be cross-checked where possible. Conflicting information must be marked as disputed rather than silently reconciled.

Do not publish national identity numbers or fragments, private contact details, exact residential addresses, or unnecessary information about relatives.

A portrait may be published only when its origin and publication basis have been reviewed. Do not use face matches or image search results as identity proof.

A correction or removal request must be reviewed promptly. Keep an internal change record without exposing the requester's personal details.

The public dataset contains approved records only. Raw extraction files and review notes must never be copied into the website output.
