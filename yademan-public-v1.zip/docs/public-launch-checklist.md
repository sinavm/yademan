# Public launch checklist

- [x] Bilingual static landing page
- [x] Responsive layout and reduced-motion support
- [x] Public dataset is empty by default
- [x] Raw source data excluded from the site repository
- [x] Data audit and editorial policy documented
- [x] GitHub Pages workflow prepared
- [ ] Create `sinavm/yademan` as a public GitHub repository
- [ ] Push the `main` branch
- [ ] Enable GitHub Pages with GitHub Actions
- [ ] Verify the deployed URL and mobile layout
- [ ] Review every proposed record and image before adding it

The repository cannot be created by the currently connected GitHub actions. No existing repository owned by `sinavm` named `yademan` was found.
